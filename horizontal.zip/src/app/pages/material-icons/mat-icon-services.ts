export class Maticons {
  iconName: any;
  iconClass: any;
 }